# Sigma: EveRecolor

**Eve colored like Venus**


KSP Forum Thread: http://forum.kerbalspaceprogram.com/threads/136075

Download Latest Release: https://github.com/Sigma88/Sigma-EveRecolor/releases/latest

Dev version: https://github.com/Sigma88/Sigma-EveRecolor/tree/Development
